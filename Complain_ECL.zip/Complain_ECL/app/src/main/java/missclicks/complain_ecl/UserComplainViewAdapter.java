package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class UserComplainViewAdapter extends RecyclerView.Adapter<UserComplainViewAdapter.ComplainViewHolder>

{
    private Context mCtx;
    private List<user_complain_view_fields> FieldsList;
    public UserComplainViewAdapter(Context mCtx, List<user_complain_view_fields> FieldsList) {
        this.mCtx = mCtx;
        this.FieldsList = FieldsList;
    }


    public ComplainViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.user_complain_view_model, null);
        return new  ComplainViewHolder(view);
    }

    public void onBindViewHolder(ComplainViewHolder holder, int position) {
        final user_complain_view_fields product = FieldsList.get(position);
        holder.Complaint_Id.setText(product.getComplaint_Id());
        holder.Problem_Description.setText(product.getProblem_Description());
        holder.Date_Of_Complaint.setText(String.valueOf(product.getDate_Of_Complaint()));
        holder.Status.setText(String.valueOf(product.getStatus()));
        holder.Mod_date.setText(toString().valueOf(product.getModification_Date()));
        holder.User_Status.setText(String.valueOf(product.getUser_Status()));

        holder.Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(mCtx, User_Complain_View_Details.class);
                i.putExtra("complain_id",product.getComplaint_Id());
                mCtx.startActivity(i);
            }
        });
    }
    public int getItemCount() {
        return FieldsList.size();
    }
    class ComplainViewHolder extends RecyclerView.ViewHolder {
        TextView Complaint_Id, Problem_Description, Date_Of_Complaint, Status,Mod_date,User_Status;
        Button Update;

        public ComplainViewHolder(View itemView) {
            super(itemView);
            Complaint_Id = itemView.findViewById(R.id.textView9);
            Problem_Description = itemView.findViewById(R.id.textView11);
            Date_Of_Complaint = itemView.findViewById(R.id.date);
            Status = itemView.findViewById(R.id.editText7);
            Mod_date = itemView.findViewById(R.id.mod_date);
            User_Status = itemView.findViewById(R.id.user_status);
            Update = itemView.findViewById(R.id.update);
        }
    }

}


