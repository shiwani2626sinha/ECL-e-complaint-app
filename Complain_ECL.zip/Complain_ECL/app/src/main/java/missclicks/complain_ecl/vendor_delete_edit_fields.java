package missclicks.complain_ecl;

public class vendor_delete_edit_fields {

    private String vendor_id;
    private String vendor_name;
    private String project_head;
    private String project_head_contact_no;
    private String vendor_location;
    private String deals_in;

    public vendor_delete_edit_fields(String vendor_id,String vendor_name,
                                     String project_head,String project_head_contact_no,String vendor_location,
                                        String deals_in)
    {
        this.vendor_id=vendor_id;
        this.vendor_name=vendor_name;
        this.project_head=project_head;
        this.project_head_contact_no=project_head_contact_no;
        this.vendor_location = vendor_location;
        this.deals_in = deals_in;
    }

    public String get_vendor_id()
    {
        return vendor_id;
    }
    public String get_vendor_name()
    {
        return vendor_name;
    }
    public String get_Project_head()
    {
        return project_head;
    }
    public String get_Project_head_contact_no()
    {
        return project_head_contact_no;
    }
    public String get_vendor_location(){return vendor_location;}
    public String get_deals_in(){return deals_in;}

}