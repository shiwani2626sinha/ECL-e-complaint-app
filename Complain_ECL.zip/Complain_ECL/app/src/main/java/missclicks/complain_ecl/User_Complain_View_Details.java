package missclicks.complain_ecl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class User_Complain_View_Details extends AppCompatActivity {

    TextView mod_date, res_date, Complain_Id, Uman_No, Name, Prob_Desc, Location,
            Building, Room_No, Department, PhoneNo, Complain_Date, Remark, status, parts_needed,
            Attended_By, User_Remark;
    Button update;
    Spinner User_Status;
    String complainid, ip, vendor, api_url, _User_Status, _User_Remark ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__complain__view__details);

        ip = getString(R.string.ip_add);
        api_url = "http://" + ip + "/Complaint_Box/viewcomplain_api.php";
        complainid = getIntent().getStringExtra("complain_id");
        status = (TextView) findViewById(R.id.status);
        Complain_Id = (TextView) findViewById(R.id.Complain_Id);
        Uman_No = (TextView) findViewById(R.id.Uman_No);
        Name = (TextView) findViewById(R.id.Name);
        Prob_Desc = (TextView) findViewById(R.id.Prob_Desc);
        Location = (TextView) findViewById(R.id.Location);
        Building = (TextView) findViewById(R.id.Building);
        Room_No = (TextView) findViewById(R.id.Room_No);
        Department = (TextView) findViewById(R.id.Department);
        PhoneNo = (TextView) findViewById(R.id.PhoneNo);
        Complain_Date = (TextView) findViewById(R.id.Complain_Date);
        mod_date = (TextView) findViewById(R.id.Modification_Date);
        res_date = (TextView) findViewById(R.id.Resolve_Date);
        Attended_By = (TextView) findViewById(R.id.attended_by);
        Remark = (TextView) findViewById(R.id.remark);
        parts_needed = (TextView) findViewById(R.id.parts_needed);
        User_Status = (Spinner) findViewById(R.id.user_status);
        User_Remark = (TextView) findViewById(R.id.user_remark);

        String[] status_list = getResources().getStringArray(R.array.User_Satus);

        ArrayAdapter<String> status_adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout,
                R.id.txt,status_list);
        User_Status.setAdapter(status_adapter);

        datafill();

    }

    public void datafill() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, api_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                if (jsonObject.getString("Complaint_Id").equals(complainid)) {
                                    Complain_Id.setText(jsonObject.getString("Complaint_Id"));
                                    Uman_No.setText(jsonObject.getString("Complainer_Id"));
                                    Name.setText(jsonObject.getString("Complainer_Name"));
                                    Department.setText(jsonObject.getString("Complainer_Deptt"));
                                    Prob_Desc.setText(jsonObject.getString("Problem_Description"));
                                    Location.setText(jsonObject.getString("Location"));
                                    Building.setText(jsonObject.getString("Building"));
                                    Room_No.setText(jsonObject.getString("Room_No"));
                                    Complain_Date.setText(jsonObject.getString("Complain_Date"));
                                    PhoneNo.setText(jsonObject.getString("phone_no"));
                                    mod_date.setText(jsonObject.getString("Modification_Date"));
                                    res_date.setText(jsonObject.getString("Resolved_Date"));
                                    vendor = jsonObject.getString("Vendor");
                                    status.setText(jsonObject.getString("Status"));
                                    Attended_By.setText(jsonObject.getString("Attended_By"));
                                    parts_needed.setText(jsonObject.getString("Parts_Needed"));
                                    Remark.setText(jsonObject.getString("Remark"));
                                    User_Remark.setText(jsonObject.getString("User_Remark"));
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error != null) {

                    Toast.makeText(getApplicationContext(), "Something went wrong.", Toast.LENGTH_LONG).show();
                }
            }
        });
        Volley.newRequestQueue(this).add(stringRequest);
    }
    public void update(View view){
        _User_Remark = User_Remark.getText().toString();
        _User_Status = User_Status.getSelectedItem().toString();
        new User_Complain_View_Details_Async(this).execute(complainid,_User_Remark,_User_Status,ip);
    }
}