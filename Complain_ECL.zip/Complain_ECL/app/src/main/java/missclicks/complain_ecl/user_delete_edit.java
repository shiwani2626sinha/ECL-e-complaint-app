package missclicks.complain_ecl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class user_delete_edit extends AppCompatActivity {

    String URL_PRODUCTS ;

    List<user_delete_edit_fields> userList;

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_delete_edit);
        recyclerView = findViewById(R.id.recyclerView_user);
        String ip = getString(R.string.ip_add);
        URL_PRODUCTS ="http://"+ip+"/Complaint_Box/userdisplay.php";
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        userList = new ArrayList<>();

        loadUserDetails();
    }
    private void loadUserDetails() {

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_PRODUCTS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            //converting the string to json array object
                            JSONArray array = new JSONArray(response);

                            //traversing through all the object
                            for (int i = 0; i < array.length(); i++) {

                                //getting product object from json array
                                JSONObject product = array.getJSONObject(i);

                                //adding the product to product list
                                userList.add(new user_delete_edit_fields(
                                        product.getString("UmanNo"),
                                        product.getString("User_Name"),
                                        product.getString("Email_id"),
                                        product.getString("phone_no"),
                                        product.getString("Role"),
                                        product.getString("Vendor")));

                            }

                            //creating adapter object and setting it to recyclerview
                            user_delete_edit_adapter adpter = new user_delete_edit_adapter(
                                    user_delete_edit.this, userList);
                            recyclerView.setAdapter(adpter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        //adding our stringrequest to queue
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
