package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class editUser_Async extends AsyncTask<String,Void,String> {
    Context context;
    public editUser_Async(Context conn) {context=conn;}
    @Override
    protected String doInBackground(String ...strings){
        try{
            String _ID=strings[0];
            String _name=strings[1];
            String _email=strings[2];
            String _phNo=strings[3];
            String _vendor=strings[4];
            String link=strings[5];
            String data= URLEncoder.encode("UserID","UTF-8")+"="+URLEncoder.encode(_ID,"UTF-8");
            data+="&"+URLEncoder.encode("UserName","UTF-8")+"="+URLEncoder.encode(_name,"UTF-8");
            data+="&"+URLEncoder.encode("emailId","UTF-8")+"="+URLEncoder.encode(_email,"UTF-8");
            data+="&"+URLEncoder.encode("phNo","UTF-8")+"="+URLEncoder.encode(_phNo,"UTF-8");
            data+="&"+URLEncoder.encode("vendor","UTF-8")+"="+URLEncoder.encode(_vendor,"UTF-8");
            URL url=new URL(link);
            URLConnection conn=url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr=new OutputStreamWriter(conn.getOutputStream());

            wr.write(data);
            wr.flush();
            BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line=null;

            while ((line=reader.readLine())!=null) {
                sb.append(line);
                break;
            }
            return sb.toString();
        }catch (Exception e) {
            return new String("Exception:" + e.getMessage());
        }
    }
    @Override
    protected void onPostExecute(String result) {
        if(result.equals("TRUE")) {
            Toast.makeText(context, "edit successful", Toast.LENGTH_SHORT).show();
            context.startActivity(new Intent(context,user_delete_edit.class));
        }
        else
            Toast.makeText(context,"error!.... ",Toast.LENGTH_SHORT).show();
    }
}

