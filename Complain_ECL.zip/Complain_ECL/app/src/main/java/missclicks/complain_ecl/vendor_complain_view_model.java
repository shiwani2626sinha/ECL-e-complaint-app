package missclicks.complain_ecl;

public class vendor_complain_view_model {
    private int id;
    private String complainer_name;
    private String location;
    private String dept;
    private String d_o_complain;
    private String prob_desc;
    private String service_eng;
    private String status;
    private String user_status;

    public vendor_complain_view_model(int id,String name, String location,String dept,
                                           String d_o_complain,String prob_desc,String service_eng,
                                      String status, String user_status){
        this.id = id;
        this.complainer_name = name;
        this.location = location;
        this.dept = dept;
        this.d_o_complain = d_o_complain;
        this.prob_desc = prob_desc;
        this.service_eng = service_eng;
        this.status = status;
        this.user_status = user_status;
    }

    public int getId(){
        return id;
    }

    public String getComplainer_name() {
        return complainer_name;
    }

    public String getLocation() {
        return location;
    }

    public String getD_o_complain() {
        return d_o_complain;
    }

    public String getProb_desc() {
        return prob_desc;
    }

    public String getDept(){
        return dept;
    }

    public String getService_eng(){return service_eng;}

    public String getStatus() {
        return status;
    }

    public String getUser_status() { return user_status;}
}
