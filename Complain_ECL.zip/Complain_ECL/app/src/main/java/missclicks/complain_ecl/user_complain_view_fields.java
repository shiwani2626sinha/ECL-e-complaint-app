package missclicks.complain_ecl;

public class user_complain_view_fields {


    private String Complaint_Id;
    private String Problem_Description;
    private String Date_Of_Complaint ;
    private String Status;
    private String Modification_Date;
    private String User_Status;


    public user_complain_view_fields(String Complaint_Id, String Problem_Description,
                                     String Date_Of_Complaint, String Status, String MOdification_Date,
                                     String User_Status) {
        this.Complaint_Id = Complaint_Id;
        this.Problem_Description = Problem_Description;
        this.Date_Of_Complaint = Date_Of_Complaint;
        this.Status = Status;
        this.Modification_Date = MOdification_Date;
        this.User_Status = User_Status;
    }

    public String getComplaint_Id() {
        return Complaint_Id;
    }

    public String getProblem_Description() {
        return Problem_Description;
    }

    public String getDate_Of_Complaint() {
        return Date_Of_Complaint;
    }

   public String getStatus() {
        return Status;
    }

    public String getModification_Date(){return Modification_Date;}

    public String getUser_Status(){return User_Status;}

}
