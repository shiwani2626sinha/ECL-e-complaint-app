package missclicks.complain_ecl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.MenuItem;
import android.view.View;

public class Start_Screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start__screen);
    }

    public void loginPage(View view)
    {
        Intent i= new Intent(this,User_Login.class);
        startActivity(i);
    }
    public void cmp_reg(View view)
    {
        Intent i= new Intent(this,Complain_Register.class);
        startActivity(i);
    }
    public void view_cmp(View view)
    {
        Intent i= new Intent(this,user_complain_view.class);
        startActivity(i);
    }
}
