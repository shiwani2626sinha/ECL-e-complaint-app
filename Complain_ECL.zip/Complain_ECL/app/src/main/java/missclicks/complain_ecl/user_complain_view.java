package missclicks.complain_ecl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;



public class user_complain_view extends AppCompatActivity {

    String URL_FIELDS;
    EditText CheckId;
    String value;

    List<user_complain_view_fields> FieldsList;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_complain_view);

        URL_FIELDS = "http://"+getString(R.string.ip_add)+"/Complaint_Box/user_complain_view.php";
        //getting the recyclerview from xml
        recyclerView = findViewById(R.id.rv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        CheckId=(EditText)findViewById(R.id.id);
        FieldsList = new ArrayList<>();
    }
    public void loadFields(View view) {
        FieldsList.clear();
        value= CheckId.getText().toString();
        final String check = "Solved";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_FIELDS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONArray array = new JSONArray(response);

                            for (int i = 0; i < array.length(); i++) {

                                JSONObject fields = array.getJSONObject(i);
                                if(value.equals(fields.getString("Complainer_Id")) && !(
                                        check.equals(fields.getString("User_Status")) &&
                                        check.equals(fields.getString("Status"))))
                                {
                                    FieldsList.add(new user_complain_view_fields(
                                            fields.getString("Complaint_Id"),
                                            fields.getString("Problem_Description"),
                                            fields.getString("Complaint_Date"),
                                            fields.getString("Status"),
                                            fields.getString("Modification_Date"),
                                            fields.getString("User_Status")
                                    ));
                                }
                            }

                            UserComplainViewAdapter adapter = new UserComplainViewAdapter
                                    (user_complain_view.this,FieldsList );
                            recyclerView.setAdapter(adapter);
                            } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        Volley.newRequestQueue(this).add(stringRequest);
        FieldsList.clear();
    }
}


