package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class user_delete_edit_adapter extends RecyclerView.Adapter<user_delete_edit_adapter.UserViewHolder> {
    private Context mCtx;
    private List<user_delete_edit_fields> UserList;

    public user_delete_edit_adapter(Context mCtx, List<user_delete_edit_fields> UserList) {
        this.mCtx = mCtx;
        this.UserList = UserList;
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.user_delete_edit_model, null);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, int position) {
        final user_delete_edit_fields details = UserList.get(position);
        holder.textViewUmanNo.setText(details.getUman_No());
        holder.textViewUserName.setText(details.getName());
        holder.textViewPhNo.setText(details.getPhNo());
        holder.textViewVendor.setText(details.getVendorName());
        holder.delbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uid = details.getUman_No();
                String ip = mCtx.getString(R.string.ip_add);
                new User_delete_Async(mCtx).execute(uid,ip);
            }
        });
        holder.editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mCtx, editUser.class);
                intent.putExtra("UmanNo", details.getUman_No());
                intent.putExtra("Name", details.getName());
                intent.putExtra("Email", details.getEmail());
                intent.putExtra("PhNo", details.getPhNo());
                intent.putExtra("Role", details.getRole());
                intent.putExtra("Vendor", details.getVendorName());
                mCtx.startActivity(intent);
            }

        });
    }


    @Override
    public int getItemCount() {
        return UserList.size();
    }
    class UserViewHolder extends RecyclerView.ViewHolder {
        TextView textViewUmanNo, textViewUserName,textViewPhNo,textViewVendor;
        Button delbtn,editbtn;
        public UserViewHolder(View itemView) {
            super(itemView);

            textViewUmanNo = itemView.findViewById(R.id.UNo);
            textViewUserName = itemView.findViewById(R.id.name);
            textViewPhNo=itemView.findViewById(R.id.phNo);
            textViewVendor = itemView.findViewById(R.id.vendor);
            delbtn = itemView.findViewById(R.id.delete);
            editbtn=itemView.findViewById(R.id.edit);
        }

    }

}

