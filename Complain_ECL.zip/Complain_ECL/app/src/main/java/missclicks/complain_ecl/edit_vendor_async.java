package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class edit_vendor_async extends AsyncTask<String,Void,String> {
    Context context;
    public edit_vendor_async(Context conn) {context=conn;}
    @Override
    protected String doInBackground(String ...strings){
        try{
            String _ID=strings[0];
            String _name=strings[1];
            String _pjHd=strings[2];
            String _phNo=strings[3];
            String _location=strings[4];
            String _dealsIn=strings[5];
            String link=strings[6];
            String data= URLEncoder.encode("VendorID","UTF-8")+"="+URLEncoder.encode(_ID,"UTF-8");
            data+="&"+URLEncoder.encode("VendorName","UTF-8")+"="+URLEncoder.encode(_name,"UTF-8");
            data+="&"+URLEncoder.encode("projectHead","UTF-8")+"="+URLEncoder.encode(_pjHd,"UTF-8");
            data+="&"+URLEncoder.encode("ContactNo","UTF-8")+"="+URLEncoder.encode(_phNo,"UTF-8");
            data+="&"+URLEncoder.encode("Location","UTF-8")+"="+URLEncoder.encode(_location,"UTF-8");
            data+="&"+URLEncoder.encode("DealsIn","UTF-8")+"="+URLEncoder.encode(_dealsIn,"UTF-8");
            URL url=new URL(link);
            URLConnection conn=url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr=new OutputStreamWriter(conn.getOutputStream());

            wr.write(data);
            wr.flush();
            BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line=null;

            while ((line=reader.readLine())!=null) {
                sb.append(line);
                break;
            }
            return sb.toString();
        }catch (Exception e) {
            return new String("Exception:" + e.getMessage());
        }
    }
    @Override
    protected void onPostExecute(String result) {
        if(result.equals("TRUE")) {
            Toast.makeText(context, "edit successful", Toast.LENGTH_SHORT).show();
            context.startActivity(new Intent(context,vendor_delete_edit.class));
        }
        else
            Toast.makeText(context,"error!.... ",Toast.LENGTH_SHORT).show();
    }
}
