package missclicks.complain_ecl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class vendor_complain_view extends AppCompatActivity {

    String api_url;
    List<vendor_complain_view_model> complain_list;
    RecyclerView recyclerView;
    TextView vendor_disp,completed_disp,pending_disp;
    String vendor,service_eng;
    int pending,completed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_complain_view);

        api_url = "http://"+getString(R.string.ip_add)+"/Complaint_Box/viewcomplain_api.php";
        recyclerView = findViewById(R.id.recyclerView_user);
        vendor_disp = (TextView)findViewById(R.id.textView8);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        vendor = getIntent().getStringExtra("vendor");
        vendor_disp.setText(vendor);
        service_eng = getIntent().getStringExtra("service_eng");
        completed_disp = (TextView)findViewById(R.id.completed);
        pending_disp = (TextView)findViewById(R.id.pending);
        complain_list = new ArrayList<>();
        pending = completed = 0;
        load_complains();
    }

    private void load_complains(){
        StringRequest stringRequest = new StringRequest(Request.Method.GET, api_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject complain = array.getJSONObject(i);
                                if (vendor.equals(complain.getString("Vendor")) &&
                                        !("Solved".equals(complain.getString("User_Status")) &&
                                                "Solved".equals(complain.getString("Status"))))
                                {
                                    complain_list.add(new vendor_complain_view_model(
                                            complain.getInt("Complaint_Id"),
                                            complain.getString("Complainer_Name"),
                                            complain.getString("Location"),
                                            complain.getString("Complainer_Deptt"),
                                            complain.getString("Complain_Date"),
                                            complain.getString("Problem_Description"),
                                            service_eng,
                                            complain.getString("Status"),
                                            complain.getString("User_Status")
                                    ));
                                }
                                if (complain.getString("Vendor").equals(vendor)) {
                                    if (complain.getString("Status").equals("Solved") &&
                                            complain.getString("User_Status").equals("Solved"))
                                        pending++;
                                    else
                                        completed++;
                                }
                            }
                            completed_disp.setText(""+pending);
                            pending_disp.setText(""+completed);
                            vendor_complain_view_adapter adapter = new vendor_complain_view_adapter
                                    (vendor_complain_view.this,complain_list);
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        Volley.newRequestQueue(this).add(stringRequest);
    }
}
