package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class User_delete_Async extends AsyncTask<String,Void,String> {
    Context context;
    public User_delete_Async(Context conn) {context=conn;}
    @Override
    protected String doInBackground(String ...strings){
        try{
            String _UmanNo=strings[0];
            String ip = strings[1];
            String link="http://"+ip+"/complaint_box/deleteUser.php";
            String data= URLEncoder.encode("umanNo","UTF-8")+"="+URLEncoder.encode(_UmanNo,"UTF-8");
            URL url=new URL(link);
            URLConnection conn=url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr=new OutputStreamWriter(conn.getOutputStream());

            wr.write(data);
            wr.flush();
            BufferedReader reader=new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb=new StringBuilder();
            String line=null;

            while ((line=reader.readLine())!=null) {
                sb.append(line);
                break;
            }
            return sb.toString();
        }catch (Exception e) {
            return new String("Exception:" + e.getMessage());
        }
    }
    @Override
    protected void onPostExecute(String result) {
        if(result.equals("True")) {
            Toast.makeText(context, "deleted successfully", Toast.LENGTH_SHORT).show();
            context.startActivity(new Intent(context,user_delete_edit.class));
        }
        else
            Toast.makeText(context,"error!.... ",Toast.LENGTH_SHORT).show();
    }


}
