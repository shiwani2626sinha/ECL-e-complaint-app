package missclicks.complain_ecl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class vendor_master extends AppCompatActivity {

    EditText vendor_id,vendor_name,project_head,contact_no,vendor_location;
    String v_id,v_name,p_head,c_no,v_location,deals,ip;
    Spinner deals_in;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_master);

        vendor_name=(EditText)findViewById(R.id.v_name);
        project_head=(EditText)findViewById(R.id.p_head);
        contact_no=(EditText)findViewById(R.id.phn);
        vendor_location=(EditText)findViewById(R.id.v_location);
        deals_in=(Spinner) findViewById(R.id.deals);
        ip = getString(R.string.ip_add);
        String[] deals = getResources().getStringArray(R.array.Deal_IN);
        ArrayAdapter<String> deals_adapter = new ArrayAdapter<String>(this,
                R.layout.spinner_layout,R.id.txt,deals);
        deals_in.setAdapter(deals_adapter);
    }

    public void add_vendor(View view)
    {
        v_name=vendor_name.getText().toString().trim();
        p_head=project_head.getText().toString().trim();
        c_no=contact_no.getText().toString().trim();
        v_location=vendor_location.getText().toString().trim();
        deals = deals_in.getSelectedItem().toString().trim();

        if(TextUtils.isEmpty(v_name) || TextUtils.isEmpty(p_head)  || TextUtils.isEmpty(c_no)
                || TextUtils.isEmpty(v_location) || TextUtils.isEmpty(deals))
            Toast.makeText(this, "Enter all credentials", Toast.LENGTH_SHORT).show();
        else
            new vendor_master_async(this).execute(v_name,p_head,c_no,v_location,deals,ip);
    }
}
