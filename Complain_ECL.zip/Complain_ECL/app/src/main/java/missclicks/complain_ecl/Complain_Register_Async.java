package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class Complain_Register_Async extends AsyncTask<String, Void, String> {

    Context context;
    public Complain_Register_Async(Context conn){context = conn;}

    @Override
    protected String doInBackground(String... strings) {
        try{
            String _Uman_No = strings[0];
            String _Name = strings[1];
            String _Prob_Desc = strings[2];
            String _Location = strings[3];
            String _Building = strings[4];
            String _Room_no = strings[5];
            String _Vend =  strings[7];
            String _Dept = strings[6];
            String _Phone_Num = strings[8];

            String link="http://"+strings[9]+"/Complaint_Box/Complain.php";
            String data  = URLEncoder.encode("Uman_No", "UTF-8") + "=" +
                    URLEncoder.encode(_Uman_No, "UTF-8");
            data += "&" + URLEncoder.encode("Name", "UTF-8") + "=" +
                    URLEncoder.encode(_Name, "UTF-8");
            data += "&" + URLEncoder.encode("Prob_Desc", "UTF-8") + "=" +
                    URLEncoder.encode(_Prob_Desc, "UTF-8");
            data += "&" + URLEncoder.encode("Location", "UTF-8") + "=" +
                    URLEncoder.encode(_Location, "UTF-8");
            data += "&" + URLEncoder.encode("Building", "UTF-8") + "=" +
                    URLEncoder.encode(_Building, "UTF-8");
            data += "&" + URLEncoder.encode("Room_No", "UTF-8") + "=" +
                    URLEncoder.encode(_Room_no, "UTF-8");
            data += "&" + URLEncoder.encode("Vend", "UTF-8") + "=" +
                    URLEncoder.encode(_Vend, "UTF-8");
            data += "&" + URLEncoder.encode("Dept", "UTF-8") + "=" +
                    URLEncoder.encode(_Dept, "UTF-8");
            data += "&" + URLEncoder.encode("Phone_Num", "UTF-8") + "=" +
                    URLEncoder.encode(_Phone_Num, "UTF-8");

            URL url = new URL(link);
            URLConnection conn = url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

            wr.write( data );
            wr.flush();

            BufferedReader reader = new BufferedReader(new
                    InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }
            return sb.toString();

        } catch(Exception e){
            return new String("Exception: " + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String result){
        if (result.equals("T")) {
            Toast.makeText(context, "Complain registered", Toast.LENGTH_LONG).show();
            context.startActivity(new Intent(context, Start_Screen.class));
        }
        else
            Toast.makeText(context, "Complain Not Registered", Toast.LENGTH_LONG).show();

    }
}
