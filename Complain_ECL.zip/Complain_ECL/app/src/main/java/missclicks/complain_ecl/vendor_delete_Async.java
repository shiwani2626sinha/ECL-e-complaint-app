package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class vendor_delete_Async extends AsyncTask<String,Void,String> {

    Context conn;
    String vid;

    public vendor_delete_Async(Context con) {
        conn = con;

    }

    protected String doInBackground(String... strings) {


        try {
            vid = strings[0];
            String ip = strings[1];
            String link="http://"+ip+"/Complaint_Box/delete_vendor.php";
            String data  = URLEncoder.encode("vendor_id", "UTF-8") + "=" +
                    URLEncoder.encode(vid, "UTF-8");

            URL url = new URL(link);
            URLConnection conn = url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

            wr.write( data );
            wr.flush();

            BufferedReader reader = new BufferedReader(new
                    InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }
            return sb.toString();

        } catch(Exception e){
            return new String("Exception: " + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String result){
        if (result.equals("TRUE")) {
            Toast.makeText(conn, "Deleted", Toast.LENGTH_LONG).show();
            conn.startActivity(new Intent(conn, vendor_delete_edit.class));
        }
        else
            Toast.makeText(conn,result,Toast.LENGTH_LONG).show();
    }
}