package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class User_Complain_View_Details_Async extends AsyncTask<String, Void, String> {
    Context context;
    public  User_Complain_View_Details_Async(Context conn){context = conn;}

    @Override
    protected String doInBackground(String... strings) {
        try{
            String Complain_id = strings[0];
            String status = strings[2];
            String remark = strings[1];
            String ip = strings[3];

            String link="http://"+ip+"/Complaint_Box/User_Complain_update.php";
            String data  = URLEncoder.encode("Complaint_Id", "UTF-8") + "=" +
                    URLEncoder.encode(Complain_id, "UTF-8");
            data += "&" + URLEncoder.encode("status", "UTF-8") + "=" +
                    URLEncoder.encode(status, "UTF-8");
            data += "&" + URLEncoder.encode("remark", "UTF-8") + "=" +
                    URLEncoder.encode(remark, "UTF-8");

            URL url = new URL(link);
            URLConnection conn = url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

            wr.write( data );
            wr.flush();

            BufferedReader reader = new BufferedReader(new
                    InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }
            return sb.toString();

        } catch(Exception e){
            return new String("Exception: " + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String result){
        if (result.equals("T")) {
            Toast.makeText(context, "Complaint Updated", Toast.LENGTH_LONG).show();
            Intent i = new Intent(context, user_complain_view.class);
            context.startActivity(i);

        }
        else
            Toast.makeText(context, "Complaint Not Updated", Toast.LENGTH_LONG).show();
    }
}
