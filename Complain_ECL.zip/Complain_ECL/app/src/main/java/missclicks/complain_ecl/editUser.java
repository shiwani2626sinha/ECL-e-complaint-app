package missclicks.complain_ecl;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class editUser extends AppCompatActivity {
    TextView edUman,edRole;
    EditText edName,edEmail,edPhNo;
    Spinner edVendor;
    Button edSave;
    String umanHolder,nameHolder,emailHolder,phNoHolder,roleHolder,vendorHolder;
    String url,ip;
    ArrayAdapter<String> vend_adapter;
    ArrayList<String> vend = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);
        ip = getString(R.string.ip_add);
        url="http://"+ip+"/Complaint_Box/editUser.php";
        edUman=(TextView)findViewById(R.id.umanNo);
        edName=(EditText)findViewById(R.id.name);
        edEmail=(EditText)findViewById(R.id.email);
        edPhNo= (EditText)findViewById(R.id.phNo);
        edRole=(TextView) findViewById(R.id.role);
        edVendor=(Spinner)findViewById(R.id.vendor);
        edSave=(Button)findViewById(R.id.saveBtn);

        umanHolder=getIntent().getStringExtra("UmanNo");
        nameHolder=getIntent().getStringExtra("Name");
        emailHolder=getIntent().getStringExtra("Email");
        phNoHolder=getIntent().getStringExtra("PhNo");
        roleHolder=getIntent().getStringExtra("Role");
        vendorHolder=getIntent().getStringExtra("Vendor");

        vend_adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout,R.id.txt,vend);
        edVendor.setAdapter(vend_adapter);

        edUman.setText(umanHolder);
        edName.setText(nameHolder);
        edEmail.setText(emailHolder);
        edPhNo.setText(phNoHolder);
        edRole.setText(roleHolder);
        edVendor.setSelection(vend_adapter.getPosition(vendorHolder));
        edSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUser();
            }
        });

    }

    public void onStart(){
        super.onStart();
        editUser.BackTask_Vendor btv = new editUser.BackTask_Vendor();
        btv.execute();
    }

    private class BackTask_Vendor extends AsyncTask<Void,Void,Void> {
        ArrayList<String> list;

        protected void onPreExecute(){
            super.onPreExecute();
            list = new ArrayList<>();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            InputStream is = null;
            String result = "";
            try{
                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost("http://"+ip+"/Complaint_Box/get_vendor.php");
                org.apache.http.HttpResponse response = httpClient.execute(httpPost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
            }catch (IOException e){
                e.printStackTrace();
            }

            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                String line = null;
                while ((line = reader.readLine())!= null){
                    result+=line;
                }
                is.close();
            }catch (Exception e){
                e.printStackTrace();
            }
            //parse json data
            try{
                JSONArray jsonArray = new JSONArray(result);
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    list.add(jsonObject.getString("Vendor_Name"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(Void result){
            vend.addAll(list);
            vend_adapter.notifyDataSetChanged();
        }
    }

    public void saveUser() {
        String  _Uman=edUman.getText().toString().trim();
        String  _Name=edName.getText().toString().trim();
        String  _Email=edEmail.getText().toString().trim();
        String  _PhNo= edPhNo.getText().toString().trim();
        String _Vendor=edVendor.getSelectedItem().toString().trim();
        new editUser_Async(this).execute(_Uman,_Name,_Email,_PhNo,_Vendor,url);
    }
}
