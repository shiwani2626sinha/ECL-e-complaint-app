package missclicks.complain_ecl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class vendor_delete_edit extends AppCompatActivity {

    String URL_FIELDS;

    List<vendor_delete_edit_fields> FieldsList;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_delete_edit);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        FieldsList = new ArrayList<>();
        URL_FIELDS = "http://"+ getString(R.string.ip_add)+"/complaint_box/display_vendor.php";
        loadFields();
    }
    private void loadFields() {

        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_FIELDS,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject fields = array.getJSONObject(i);
                                FieldsList.add(new vendor_delete_edit_fields(
                                        fields.getString("Vendor_Id"),
                                        fields.getString("Vendor_Name"),
                                        fields.getString("ProjectHead"),
                                        fields.getString("ProjectHead_ContactNo"),
                                        fields.getString("Location"),
                                        fields.getString("deals_in")
                                ));
                            }

                            vendor_delete_edit_adapter adapter = new vendor_delete_edit_adapter
                                    (vendor_delete_edit.this,FieldsList );
                            recyclerView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        Volley.newRequestQueue(this).add(stringRequest);
    }
}


