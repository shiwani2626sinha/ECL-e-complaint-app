package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public  class vendor_master_async extends AsyncTask<String,Void,String>

{
    Context context;

    public vendor_master_async(Context con) {
        context = con;
    }


    @Override
    protected String doInBackground(String... strings) {

        try {

            String vendor_name = strings[0];
            String project_head = strings[1];
            String contact_no = strings[2];
            String vendor_loaction = strings[3];
            String deals_in = strings[4];

            String link = "http://"+strings[5]+"/Complaint_Box/add_vendor.php";
            String data = URLEncoder.encode("vendor_name", "UTF-8") + "=" +
                    URLEncoder.encode(vendor_name, "UTF-8");
            data += "&" + URLEncoder.encode("project_head", "UTF-8") + "=" +
                    URLEncoder.encode(project_head, "UTF-8");
            data += "&" + URLEncoder.encode("contact_no", "UTF-8") + "=" +
                    URLEncoder.encode(contact_no, "UTF-8");
            data += "&" + URLEncoder.encode("vendor_location", "UTF-8") + "=" +
                    URLEncoder.encode(vendor_loaction, "UTF-8");
            data += "&" + URLEncoder.encode("deals_in", "UTF-8") + "=" +
                    URLEncoder.encode(deals_in, "UTF-8");


            URL url = new URL(link);
            URLConnection conn = url.openConnection();

            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

            wr.write(data);
            wr.flush();

            BufferedReader reader = new BufferedReader(new
                    InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }
            return sb.toString();

        } catch (Exception e) {
            return new String("Exception: " + e.getMessage());
        }
    }

    @Override
    protected void onPostExecute(String result) {
        if (result.equals("T")) {
            Toast.makeText(context, "New  Vendor added", Toast.LENGTH_LONG).show();
            context.startActivity(new Intent(context, Admin_home.class));
        }
        else
            Toast.makeText(context, "Error!!", Toast.LENGTH_LONG).show();
    }
}