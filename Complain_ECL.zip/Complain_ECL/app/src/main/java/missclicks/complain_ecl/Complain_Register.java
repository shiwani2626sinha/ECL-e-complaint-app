package missclicks.complain_ecl;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.toolbox.HttpResponse;

import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static android.widget.Toast.*;
import static android.widget.Toast.LENGTH_SHORT;

public class Complain_Register extends AppCompatActivity {

    EditText Uman_No,Name,Prob_Desc, Building,Room_no,Phone_num;
    Spinner Dept, Vend,Location;
    Button btn;
    String ip;
    ArrayAdapter<String> dept_adapter;
    ArrayList<String> dept = new ArrayList<>();

    ArrayAdapter<String> vend_adapter;
    ArrayList<String> vend = new ArrayList<>();

    ArrayAdapter<String> area_adapter;
    ArrayList<String> area = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complain__register);

        ip = getString(R.string.ip_add);
        Uman_No = (EditText)findViewById(R.id.Uman_No);
        Name = (EditText)findViewById(R.id.Name);
        Prob_Desc = (EditText)findViewById(R.id.Problem);
        Location = (Spinner)findViewById(R.id.Location);
        Building =(EditText)findViewById(R.id.Building);
        Room_no = (EditText)findViewById(R.id.Room_No);
        Vend = (Spinner)findViewById(R.id.spinner_vendor);
        Dept = (Spinner)findViewById(R.id.spinner_dept);
        btn = (Button)findViewById(R.id.confirm);
        Phone_num = (EditText)findViewById(R.id.Phone_Number);

        vend_adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout,R.id.txt,vend);
        Vend.setAdapter(vend_adapter);

        dept_adapter = new ArrayAdapter<String>(this,R.layout.spinner_layout,R.id.txt,dept);
        Dept.setAdapter(dept_adapter);

        area_adapter = new ArrayAdapter<String>(this,R.layout.spinner_layout,R.id.txt,area);
        Location.setAdapter(area_adapter);
    }

    public void onStart(){
        super.onStart();
        BackTask_dept bt = new BackTask_dept();
        bt.execute();
        BackTask_Vendor btv = new BackTask_Vendor();
        btv.execute();
        BackTask_area bta  = new BackTask_area();
        bta.execute();
    }

    private class BackTask_Vendor extends AsyncTask<Void,Void,Void>{
        ArrayList<String> list;

        protected void onPreExecute(){
            super.onPreExecute();
            list = new ArrayList<>();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            InputStream is = null;
            String result = "";
            try{
                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost("http://"+ip+"/Complaint_Box/get_vendor.php");
                org.apache.http.HttpResponse response = httpClient.execute(httpPost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
            }catch (IOException e){
                e.printStackTrace();
            }

            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                String line = null;
                while ((line = reader.readLine())!= null){
                    result+=line;
                }
                is.close();
            }catch (Exception e){
                e.printStackTrace();
            }
            //parse json data
            try{
                JSONArray jsonArray = new JSONArray(result);
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    list.add(jsonObject.getString("Vendor_Name"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(Void result){
            vend.addAll(list);
            vend_adapter.notifyDataSetChanged();
        }
    }

    private class BackTask_area extends AsyncTask<Void,Void,Void>{
        ArrayList<String> list;

        protected void onPreExecute(){
            super.onPreExecute();
            list = new ArrayList<>();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            InputStream is = null;
            String result = "";
            try{
                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost("http://"+ip+"/Complaint_Box/get_area.php");
                org.apache.http.HttpResponse response = httpClient.execute(httpPost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
            }catch (IOException e){
                e.printStackTrace();
            }

            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                String line = null;
                while ((line = reader.readLine())!= null){
                    result+=line;
                }
                is.close();
            }catch (Exception e){
                e.printStackTrace();
            }
            //parse json data
            try{
                JSONArray jsonArray = new JSONArray(result);
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    list.add(jsonObject.getString("Area_Name"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(Void result){
            area.addAll(list);
            area_adapter.notifyDataSetChanged();
        }
    }

    private class BackTask_dept extends AsyncTask<Void,Void,Void>{
        ArrayList<String> list;

        protected void onPreExecute(){
            super.onPreExecute();
            list = new ArrayList<>();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            InputStream is = null;
            String result = "";
            try{
                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost("http://"+ip+"/Complaint_Box/get_dept.php");
                org.apache.http.HttpResponse response = httpClient.execute(httpPost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
            }catch (IOException e){
                e.printStackTrace();
            }

            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                String line = null;
                while ((line = reader.readLine())!= null){
                    result+=line;
                }
                is.close();
            }catch (Exception e){
                e.printStackTrace();
            }
            //parse json data
            try{
                JSONArray jsonArray = new JSONArray(result);
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    list.add(jsonObject.getString("Dept_Name"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(Void result){
            dept.addAll(list);
            dept_adapter.notifyDataSetChanged();
        }
    }

    public void register(View view){
        String _Uman_No = Uman_No.getText().toString();
        String _Name = Name.getText().toString();
        String _Prob_Desc = Prob_Desc.getText().toString();
        String _Location = Location.getSelectedItem().toString();
        String _Building = Building.getText().toString();
        String _Room_no = Room_no.getText().toString();
        String _Vend =  Vend.getSelectedItem().toString();
        String _Dept = Dept.getSelectedItem().toString();
        String _Phone_Num = Phone_num.getText().toString();

        if(TextUtils.isEmpty(_Uman_No) || TextUtils.isEmpty(_Name) || TextUtils.isEmpty(_Prob_Desc)
                || TextUtils.isEmpty(_Building) || TextUtils.isEmpty(_Phone_Num))
            Toast.makeText(this,"Please fill up the mandatory fields",LENGTH_SHORT).show();
        else
            new Complain_Register_Async(this).execute(_Uman_No,_Name,_Prob_Desc,_Location,
                _Building,_Room_no,_Dept,_Vend,_Phone_Num,ip);
    }
}
