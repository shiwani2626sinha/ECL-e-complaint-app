package missclicks.complain_ecl;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class editVendor extends AppCompatActivity {
    EditText edProjectHead,edPjHdContNo,txLocation;
    TextView txId,txName;
    Spinner edDealsIn;
    Button edSave;
    String idHolder,nameHolder,pjHdHolder,phNoHolder,locHolder,dealHolder;
    String url;
    String[] deals;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_vendor);
        String ip = getString(R.string.ip_add);
        url="http://"+ip+"/Complaint_Box/update_vendor.php";
        deals = getResources().getStringArray(R.array.Deal_IN);

        txId=(TextView)findViewById(R.id.id);
        txName=(TextView)findViewById(R.id.name);
        edProjectHead=(EditText)findViewById(R.id.pjHd);
        edPjHdContNo= (EditText)findViewById(R.id.phNo);
        txLocation=(EditText) findViewById(R.id.loc);
        edDealsIn=(Spinner) findViewById(R.id.deal_spin);
        edSave=(Button)findViewById(R.id.saveBtn);

        ArrayAdapter<String> deals_adapter = new ArrayAdapter<String>(this,
                R.layout.spinner_layout,R.id.txt,deals);
        edDealsIn.setAdapter(deals_adapter);


        idHolder=getIntent().getStringExtra("Id");
        nameHolder=getIntent().getStringExtra("name");
        pjHdHolder=getIntent().getStringExtra("pjHd");
        phNoHolder=getIntent().getStringExtra("phNo");
        locHolder=getIntent().getStringExtra("location");
        dealHolder=getIntent().getStringExtra("dealsIn");

        txId.setText(idHolder);
        txName.setText(nameHolder);
        edProjectHead.setText(pjHdHolder);
        edPjHdContNo.setText(phNoHolder);
        txLocation.setText(locHolder);
        edSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveVendor();
            }
        });
    }
    public void saveVendor() {
        String  _pjHd=edProjectHead.getText().toString().trim();
        String  _PhNo= edPjHdContNo.getText().toString().trim();
        String _DealsIn= edDealsIn.getSelectedItem().toString();
        String _Id = txId.getText().toString();
        String _name = txName.getText().toString();
        String _Location = txLocation.getText().toString();
        new edit_vendor_async(this).execute(_Id,_name,_pjHd,_PhNo,_Location,_DealsIn,url);
    }
}
