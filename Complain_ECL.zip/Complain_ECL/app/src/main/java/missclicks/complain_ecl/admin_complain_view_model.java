package missclicks.complain_ecl;

public class admin_complain_view_model {
    private int id;
    private String complainer_name;
    private String location;
    private String dept;
    private String d_o_complain;
    private String prob_desc;
    private String status;

    public admin_complain_view_model(int id,String name, String location,String dept,
                                      String d_o_complain,String prob_desc,String status){
        this.id = id;
        this.complainer_name = name;
        this.location = location;
        this.dept = dept;
        this.d_o_complain = d_o_complain;
        this.prob_desc = prob_desc;
        this.status = status;
    }

    public int getId(){
        return id;
    }

    public String getComplainer_name() {
        return complainer_name;
    }

    public String getLocation() {
        return location;
    }

    public String getD_o_complain() {
        return d_o_complain;
    }

    public String getProb_desc() {
        return prob_desc;
    }

    public String getDept(){
        return dept;
    }

    public String getStatus() {
        return status;
    }
}
