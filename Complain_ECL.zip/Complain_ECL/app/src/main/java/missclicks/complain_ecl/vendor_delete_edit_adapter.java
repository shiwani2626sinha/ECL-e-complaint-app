package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class vendor_delete_edit_adapter  extends RecyclerView.Adapter<vendor_delete_edit_adapter.VendorViewHolder>
{

    private Context mCtx;
    private List<vendor_delete_edit_fields> FieldsList;
    public vendor_delete_edit_adapter(Context mCtx, List<vendor_delete_edit_fields>FieldsList) {
        this.mCtx = mCtx;
        this.FieldsList = FieldsList;}

    public VendorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.vendor_delete_edit_model, null);
        return new VendorViewHolder(view);
    }
    public void onBindViewHolder(VendorViewHolder holder, int position)
    {
        final vendor_delete_edit_fields product = FieldsList.get(position);
        holder.vendor_id.setText(product.get_vendor_id());
        holder.vendor_name.setText(product.get_vendor_name());
        holder.project_head.setText(product.get_Project_head());
        holder.project_head_contact_no.setText(product.get_Project_head_contact_no());
        holder.button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(mCtx,editVendor.class);
                intent.putExtra("Id", product.get_vendor_id());
                intent.putExtra("name", product.get_vendor_name());
                intent.putExtra("pjHd", product.get_Project_head());
                intent.putExtra("phNo",product.get_Project_head_contact_no());
                intent.putExtra("location", product.get_vendor_location());
                intent.putExtra("dealsIn", product.get_deals_in());
                mCtx.startActivity(intent);

            }
        });
        holder.button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vid = product.get_vendor_id();
                String ip = mCtx.getString(R.string.ip_add);
                new vendor_delete_Async(mCtx).execute(vid,ip);
            }
        });
    }
    public int getItemCount() {
        return FieldsList.size();
    }
    class VendorViewHolder extends RecyclerView.ViewHolder {
        TextView vendor_id, vendor_name, project_head,project_head_contact_no,button8,button7;
        public VendorViewHolder(View itemView) {
            super(itemView);
            vendor_id = itemView.findViewById(R.id.textView14);
            vendor_name = itemView.findViewById(R.id.textView16);
            project_head = itemView.findViewById(R.id.textView18);
            project_head_contact_no=itemView.findViewById(R.id.textView20);
            button8=itemView.findViewById(R.id.button8);
            button7=itemView.findViewById(R.id.button7);
        }
    }

}
