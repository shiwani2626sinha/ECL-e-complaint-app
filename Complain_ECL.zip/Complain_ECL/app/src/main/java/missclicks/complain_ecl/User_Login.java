package missclicks.complain_ecl;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class User_Login extends AppCompatActivity{

    EditText username,password;
    String emp_name, emp_pass,ip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__login);

        username = (EditText)findViewById(R.id.eng_username);
        password = (EditText)findViewById(R.id.eng_password);
        ip = getString(R.string.ip_add);
    }

    public void signin(View view){
        emp_name = username.getText().toString().trim();
        emp_pass = password.getText().toString().trim();
        if (TextUtils.isEmpty(emp_name) || TextUtils.isEmpty(emp_pass))
            Toast.makeText(this,"Enter Valid Credentials",Toast.LENGTH_SHORT).show();
        else
            new Login_Async(this).execute(emp_name,emp_pass,ip);
    }
}
