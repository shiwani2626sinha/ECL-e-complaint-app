package missclicks.complain_ecl;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class vendor_complain_view_details extends AppCompatActivity {


    Calendar myCalendar;
    TextView mod_date,res_date,Complain_Id,Uman_No,Name,Prob_Desc,Location,
                Building,Room_No,Department,Attended_By,PhoneNo,Complain_Date,User_Status,User_Remark;
    EditText Remark;
    Button btn_res,update;
    Spinner status;
    String complainid,Res_date,Status,ip,vendor,api_url,remark,attended_by,parts_or_not,service_eng;
    RadioGroup radioGroup;
    RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor_complain_view_details);

        ip = getString(R.string.ip_add);
        api_url = "http://"+ip+"/Complaint_Box/viewcomplain_api.php";
        complainid = getIntent().getStringExtra("complain_id");
        service_eng = getIntent().getStringExtra("service_eng");
        myCalendar = Calendar.getInstance();
        btn_res = (Button)findViewById(R.id.Select_Res_Date);
        status = (Spinner)findViewById(R.id.spinner_status);
        Complain_Id = (TextView)findViewById(R.id.Complain_Id);
        Uman_No = (TextView)findViewById(R.id.Uman_No);
        Name = (TextView)findViewById(R.id.Name);
        Prob_Desc = (TextView)findViewById(R.id.Prob_Desc);
        Location = (TextView)findViewById(R.id.Location);
        Building = (TextView)findViewById(R.id.Building);
        Room_No = (TextView)findViewById(R.id.Room_No);
        Department = (TextView)findViewById(R.id.Department);
        PhoneNo = (TextView)findViewById(R.id.PhoneNo);
        Complain_Date = (TextView)findViewById(R.id.Complain_Date);
        mod_date = (TextView)findViewById(R.id.Modification_Date);
        res_date = (TextView)findViewById(R.id.Resolve_Date);
        update  = (Button)findViewById(R.id.update);
        Attended_By = (TextView)findViewById(R.id.attended_by);
        radioGroup = (RadioGroup)findViewById(R.id.parts_needed_group);
        Remark= (EditText)findViewById(R.id.remark);
        User_Status = (TextView)findViewById(R.id.user_status);
        User_Remark = (TextView)findViewById(R.id.user_remark);

        String[] status_list = getResources().getStringArray(R.array.Status_array);

        final DatePickerDialog.OnDateSetListener date_res = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                update_resdate();
            }
        };
        btn_res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(vendor_complain_view_details.this, date_res, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        ArrayAdapter<String> status_adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout,
                R.id.txt,status_list);
        status.setAdapter(status_adapter);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update_details();
            }
        });
        datafill();
    }

    public void update_resdate(){
        String myFormat = "yyyy-MM-dd"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        res_date.setText(sdf.format(myCalendar.getTime()));
    }

    public void datafill(){
        StringRequest stringRequest = new StringRequest(Request.Method.GET, api_url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try{
                            JSONArray jsonArray = new JSONArray(response);
                            for(int i=0; i<jsonArray.length();i++){
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                if (jsonObject.getString("Complaint_Id").equals(complainid)){
                                    Complain_Id.setText(jsonObject.getString("Complaint_Id"));
                                    Uman_No.setText(jsonObject.getString("Complainer_Id"));
                                    Name.setText(jsonObject.getString("Complainer_Name"));
                                    Department.setText(jsonObject.getString("Complainer_Deptt"));
                                    Prob_Desc.setText(jsonObject.getString("Problem_Description"));
                                    Location.setText(jsonObject.getString("Location"));
                                    Building.setText(jsonObject.getString("Building"));
                                    Room_No.setText(jsonObject.getString("Room_No"));
                                    Complain_Date.setText(jsonObject.getString("Complain_Date"));
                                    PhoneNo.setText(jsonObject.getString("phone_no"));
                                    mod_date.setText(jsonObject.getString("Modification_Date"));
                                    res_date.setText(jsonObject.getString("Resolved_Date"));
                                    vendor = jsonObject.getString("Vendor");
                                    if (jsonObject.getString("Parts_Needed").equals("YES"))
                                        radioGroup.check(R.id.yes);
                                    else if(jsonObject.getString("Parts_Needed").equals("NO"))
                                        radioGroup.check(R.id.no);
                                    else
                                        radioGroup.check(R.id.no);
                                    Attended_By.setText(jsonObject.getString("Attended_By"));
                                    Remark.setText(jsonObject.getString("Remark"));
                                    User_Status.setText(jsonObject.getString("User_Status"));
                                    User_Remark.setText(jsonObject.getString("User_Remark"));
                                }
                            }
                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if(error != null){

                    Toast.makeText(getApplicationContext(), "Something went wrong.", Toast.LENGTH_LONG).show();
                }
            }
        });
        Volley.newRequestQueue(this).add(stringRequest);
    }

    public void update_details(){
        Res_date = res_date.getText().toString();
        Status = status.getSelectedItem().toString();
        remark = Remark.getText().toString();
        attended_by = service_eng;
        int selected = radioGroup.getCheckedRadioButtonId();
        radioButton = (RadioButton)findViewById(selected);
        parts_or_not = radioButton.getText().toString();
        new vendor_complain_view_details_async(this).execute(complainid,
                   Res_date,Status,ip,vendor,remark,attended_by,parts_or_not);
    }
}
