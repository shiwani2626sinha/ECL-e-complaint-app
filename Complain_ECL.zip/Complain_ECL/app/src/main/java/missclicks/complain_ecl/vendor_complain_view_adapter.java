package missclicks.complain_ecl;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import java.util.List;

public class vendor_complain_view_adapter extends
                    RecyclerView.Adapter<vendor_complain_view_adapter.complain_view_holder>{
    private Context context;
    private List<vendor_complain_view_model> complain_list;

    public vendor_complain_view_adapter(Context context,
                                        List<vendor_complain_view_model> complain_list){
        this.context = context;
        this.complain_list = complain_list;
    }

    @Override
    public complain_view_holder onCreateViewHolder(ViewGroup parent, int viewtype){
        LayoutInflater inflater =LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.vendor_complain_view_model,null);
        return new complain_view_holder(view);
    }

    @Override
    public void onBindViewHolder(final complain_view_holder holder, int position){
        final vendor_complain_view_model complain = complain_list.get(position);

        holder.complainid.setText(String.valueOf(complain.getId()));
        holder.complainer_name.setText(complain.getComplainer_name());
        holder.location.setText(complain.getLocation());
        holder.dept.setText(complain.getDept());
        holder.d_o_complain.setText(complain.getD_o_complain());
        holder.prob_desc.setText(complain.getProb_desc());
        holder.Status.setText(complain.getStatus());
        holder.User_Status.setText(complain.getUser_status());

        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent (context, vendor_complain_view_details.class);
                i.putExtra("complain_id",(String.valueOf(complain.getId())));
                i.putExtra("service_eng",(String.valueOf(complain.getService_eng())));
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount(){
        return complain_list.size();
    }

    class complain_view_holder extends RecyclerView.ViewHolder {
        TextView complainid,complainer_name,location,dept,d_o_complain,prob_desc,Status,User_Status;
        Button btn;
        public complain_view_holder(View itemView) {
            super(itemView);

            complainid = itemView.findViewById(R.id.complain_id);
            complainer_name = itemView.findViewById(R.id.complainer_name);
            location = itemView.findViewById(R.id.Location);
            dept = itemView.findViewById(R.id.department);
            d_o_complain = itemView.findViewById(R.id.d_o_complain);
            prob_desc = itemView.findViewById(R.id.prob_desc);
            Status = itemView.findViewById(R.id.status);
            User_Status = itemView.findViewById(R.id.user_status);
            btn = itemView.findViewById(R.id.submit);
        }
    }
}