package missclicks.complain_ecl;

public class user_delete_edit_fields {
    private String umanNo;
    private String userName;
    private String email;
    private String phNo;
    private String role;
    private String vendorName;

    public user_delete_edit_fields( String umanNo, String userName,
                                    String email,String phNo,String role,String vendorName) {
        this.umanNo = umanNo;
        this.userName = userName;
        this.email=email;
        this.phNo=phNo;
        this.role=role;
        this.vendorName=vendorName;
    }
    public String getUman_No() {
        return umanNo;
    }

    public String getName() {
        return userName;
    }

    public String getEmail(){ return email;}

    public String getPhNo() {
        return phNo;
    }

    public String getRole() {
        return role;
    }

    public String getVendorName() {
        return vendorName;
    }
}


