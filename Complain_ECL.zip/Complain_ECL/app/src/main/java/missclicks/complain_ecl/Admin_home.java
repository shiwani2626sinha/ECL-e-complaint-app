package missclicks.complain_ecl;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Admin_home extends AppCompatActivity {

    ArrayAdapter<String> vend_adapter;
    ArrayList<String> vend = new ArrayList<>();
    Spinner Vend1;
    String ip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        ip = getString(R.string.ip_add);
        Vend1 =(Spinner)findViewById(R.id.spinner);
        vend_adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout,R.id.txt,vend);
        Vend1.setAdapter(vend_adapter);
    }


    public void onStart(){
        super.onStart();
        Admin_home.BackTask_Vendor btv = new Admin_home.BackTask_Vendor();
        vend.clear();
        btv.execute();
    }

    private class BackTask_Vendor extends AsyncTask<Void,Void,Void> {
        ArrayList<String> list;

        protected void onPreExecute(){
            super.onPreExecute();
            list = new ArrayList<>();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            InputStream is = null;
            String result = "";
            try{
                HttpClient httpClient = new DefaultHttpClient();
                HttpPost httpPost = new HttpPost("http://"+ip+"/Complaint_Box/get_vendor.php");
                org.apache.http.HttpResponse response = httpClient.execute(httpPost);
                HttpEntity entity = response.getEntity();
                is = entity.getContent();
            }catch (IOException e){
                e.printStackTrace();
            }

            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                String line = null;
                while ((line = reader.readLine())!= null){
                    result+=line;
                }
                is.close();
            }catch (Exception e){
                e.printStackTrace();
            }
            //parse json data
            try{
                JSONArray jsonArray = new JSONArray(result);
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    list.add(jsonObject.getString("Vendor_Name"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(Void result){
            vend.addAll(list);
            vend_adapter.notifyDataSetChanged();
        }
    }

    public void mst_table(View view)
    {
        Intent i= new Intent(this,add_user.class);
        startActivity(i);
    }

    public void vendor_table(View view)
    {
        Intent i= new Intent(this,vendor_master.class);
        startActivity(i);
    }

    public void vendor_edit_delete(View view){
        Intent i = new Intent(this, vendor_delete_edit.class);
        startActivity(i);
    }

    public void user_edit_delete(View view){
        Intent i = new Intent(this,user_delete_edit.class);
        startActivity(i);
    }

    public void getStatus(View view){
        String result = Vend1.getSelectedItem().toString();
        Intent i = new Intent(this, Admin_Complain_View.class);
        i.putExtra("vendor",result);
        this.startActivity(i);
    }
}
